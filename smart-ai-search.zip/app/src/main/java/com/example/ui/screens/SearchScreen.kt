package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.SearchMode
import com.example.ui.SearchViewModel
import com.example.ui.components.HistoryFavoritesSheet
import com.example.ui.components.TelegramChatBubble
import com.example.ui.components.TelegramInputBar
import com.example.ui.components.TelegramTopBar
import java.util.Locale

@Composable
fun SearchScreen(
    viewModel: SearchViewModel = viewModel()
) {
    val context = LocalContext.current
    val inputText by viewModel.inputText.collectAsState()
    val selectedMode by viewModel.selectedMode.collectAsState()
    val siteFilters by viewModel.siteFilters.collectAsState()
    val customDomainInput by viewModel.customDomainInput.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val isTtsSpeaking by viewModel.isTtsSpeaking.collectAsState()
    val speakingMessageId by viewModel.speakingMessageId.collectAsState()
    val showHistorySheet by viewModel.showHistorySheet.collectAsState()
    val historyList by viewModel.historyList.collectAsState()
    val favoriteList by viewModel.favoriteList.collectAsState()

    val listState = rememberLazyListState()

    // Auto-scroll to bottom on new message
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    // Voice recognition launcher
    val voiceLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                viewModel.sendMessage(spoken)
            }
        }
    }

    val triggerVoiceInput: () -> Unit = {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale("uk", "UA").toString())
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Скажіть повідомлення для AI...")
            }
            voiceLauncher.launch(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Голосове введення недоступне на цьому пристрої", Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TelegramTopBar(
                selectedMode = selectedMode,
                onModeSelected = viewModel::onModeSelected,
                onOpenHistory = { viewModel.setShowHistorySheet(true) },
                onClearChat = viewModel::clearChat,
                historyCount = historyList.size
            )
        },
        bottomBar = {
            TelegramInputBar(
                inputText = inputText,
                onInputTextChanged = viewModel::onInputTextChanged,
                onSendMessage = { text -> viewModel.sendMessage(text) },
                selectedMode = selectedMode,
                onVoiceClick = triggerVoiceInput,
                quickSuggestions = viewModel.quickSuggestions,
                onSuggestionClick = { suggestion ->
                    viewModel.sendMessage(suggestion)
                },
                siteFilters = siteFilters,
                onToggleSiteFilter = viewModel::toggleSiteFilter,
                customDomainInput = customDomainInput,
                onCustomDomainInputChanged = viewModel::onCustomDomainInputChanged,
                onAddCustomDomain = viewModel::addCustomDomain,
                onRemoveCustomSite = viewModel::removeCustomSite
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp)
            ) {
                items(
                    items = messages,
                    key = { it.id }
                ) { message ->
                    TelegramChatBubble(
                        message = message,
                        isSpeaking = isTtsSpeaking && speakingMessageId == message.id,
                        onSpeakToggle = { id, text -> viewModel.speakMessage(id, text) },
                        onOpenUrl = { url -> viewModel.openUrlInBrowser(context, url) },
                        onExplainWiki = { id, article -> viewModel.explainWikipediaArticleInChat(id, article) },
                        onPromptClick = { prompt -> viewModel.sendMessage(prompt) }
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }

        // History & Bookmarks Bottom Sheet
        if (showHistorySheet) {
            HistoryFavoritesSheet(
                historyList = historyList,
                favoriteList = favoriteList,
                onSelectQuery = { selectedQuery, modeName ->
                    val mode = try {
                        SearchMode.valueOf(modeName)
                    } catch (e: Exception) {
                        SearchMode.AI_OVERVIEW
                    }
                    viewModel.onModeSelected(mode)
                    viewModel.sendMessage(selectedQuery, mode)
                },
                onToggleFavorite = viewModel::toggleFavorite,
                onDeleteItem = viewModel::deleteHistoryItem,
                onClearAll = viewModel::clearAllHistory,
                onDismiss = { viewModel.setShowHistorySheet(false) }
            )
        }
    }
}
