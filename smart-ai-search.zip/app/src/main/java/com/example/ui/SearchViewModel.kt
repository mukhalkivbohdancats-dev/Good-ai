package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.speech.tts.TextToSpeech
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.GeminiService
import com.example.data.api.WikipediaService
import com.example.data.db.AppDatabase
import com.example.data.db.SearchHistoryEntity
import com.example.data.model.ChatMessage
import com.example.data.model.SearchMode
import com.example.data.model.SiteFilter
import com.example.data.model.WikipediaArticle
import com.example.data.repository.SearchRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID

class SearchViewModel(application: Application) : AndroidViewModel(application), TextToSpeech.OnInitListener {

    private val repository: SearchRepository
    private var tts: TextToSpeech? = null
    private val _isTtsSpeaking = MutableStateFlow(false)
    val isTtsSpeaking: StateFlow<Boolean> = _isTtsSpeaking.asStateFlow()
    private val _speakingMessageId = MutableStateFlow<String?>(null)
    val speakingMessageId: StateFlow<String?> = _speakingMessageId.asStateFlow()

    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    private val _selectedMode = MutableStateFlow(SearchMode.AI_OVERVIEW)
    val selectedMode: StateFlow<SearchMode> = _selectedMode.asStateFlow()

    private val defaultPresetSites = listOf(
        SiteFilter("wiki", "Вікіпедія", "uk.wikipedia.org", "📚", true),
        SiteFilter("google", "Google Джерела", "google.com", "🔍", true),
        SiteFilter("reddit", "Reddit", "reddit.com", "💬", false),
        SiteFilter("github", "GitHub", "github.com", "💻", false),
        SiteFilter("stackoverflow", "StackOverflow", "stackoverflow.com", "🛠️", false),
        SiteFilter("medium", "Medium", "medium.com", "📝", false),
        SiteFilter("bbc", "BBC News", "bbc.com", "📰", false),
        SiteFilter("nauka", "Наука UA", "nauka.ua", "🔬", false),
        SiteFilter("hackernews", "Hacker News", "news.ycombinator.com", "⚡", false)
    )

    private val _siteFilters = MutableStateFlow<List<SiteFilter>>(defaultPresetSites)
    val siteFilters: StateFlow<List<SiteFilter>> = _siteFilters.asStateFlow()

    private val _customDomainInput = MutableStateFlow("")
    val customDomainInput: StateFlow<String> = _customDomainInput.asStateFlow()

    private val _showSiteFilterBar = MutableStateFlow(false)
    val showSiteFilterBar: StateFlow<Boolean> = _showSiteFilterBar.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isThinking = MutableStateFlow(false)
    val isThinking: StateFlow<Boolean> = _isThinking.asStateFlow()

    private val _showHistorySheet = MutableStateFlow(false)
    val showHistorySheet: StateFlow<Boolean> = _showHistorySheet.asStateFlow()

    val historyList: StateFlow<List<SearchHistoryEntity>>
    val favoriteList: StateFlow<List<SearchHistoryEntity>>

    val quickSuggestions = listOf(
        "Квантові комп'ютери простими словами",
        "Штучний інтелект Gemini 3.5",
        "Історія створення Вікіпедії",
        "Космічний телескоп Джеймс Вебб",
        "Як вивчити програмування з нуля",
        "Відновлювана енергетика"
    )

    init {
        val db = AppDatabase.getDatabase(application)
        repository = SearchRepository(
            geminiService = GeminiService(),
            wikipediaService = WikipediaService(),
            historyDao = db.searchHistoryDao()
        )

        historyList = repository.historyFlow.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        favoriteList = repository.favoritesFlow.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        try {
            tts = TextToSpeech(application, this)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Add Telegram-style Welcome Message from AI Bot
        val welcomeMessage = ChatMessage(
            id = "welcome_msg",
            isUser = false,
            text = "Привіт! Я твій інтелектуальний AI-пошуковик 🤖.\n\nОбирай одну з 4 вкладок зверху та пиши будь-яке запитання:\n• 🤖 AI Огляд — повний структурований синтез\n• 📚 Вікіпедія — статті та швидке пояснення\n• 🔍 Google — веб-джерела та прямий пошук\n• 🌐 Сайти — фокусування на обраних доменах\n\nНапиши запитання або обери одну з підказок нижче!",
            mode = SearchMode.AI_OVERVIEW
        )
        _messages.value = listOf(welcomeMessage)

        // Seed initial query demo
        sendMessage("Штучний інтелект та майбутнє технологій", SearchMode.AI_OVERVIEW)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("uk", "UA"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale.US)
            }
        }
    }

    fun onInputTextChanged(text: String) {
        _inputText.value = text
    }

    fun onModeSelected(mode: SearchMode) {
        _selectedMode.value = mode
        if (mode == SearchMode.CUSTOM_SITES) {
            _showSiteFilterBar.value = true
        }
    }

    fun toggleSiteFilterBar() {
        _showSiteFilterBar.value = !_showSiteFilterBar.value
    }

    fun toggleSiteFilter(siteId: String) {
        _siteFilters.value = _siteFilters.value.map {
            if (it.id == siteId) it.copy(isSelected = !it.isSelected) else it
        }
    }

    fun onCustomDomainInputChanged(domain: String) {
        _customDomainInput.value = domain
    }

    fun addCustomDomain() {
        val raw = _customDomainInput.value.trim().lowercase()
            .removePrefix("https://")
            .removePrefix("http://")
            .removePrefix("www.")
            .removeSuffix("/")

        if (raw.isNotBlank() && !_siteFilters.value.any { it.domain.equals(raw, ignoreCase = true) }) {
            val newSite = SiteFilter(
                id = "custom_${System.currentTimeMillis()}",
                name = raw,
                domain = raw,
                iconEmoji = "🌐",
                isSelected = true
            )
            _siteFilters.value = _siteFilters.value + newSite
            _customDomainInput.value = ""
        }
    }

    fun removeCustomSite(siteId: String) {
        _siteFilters.value = _siteFilters.value.filterNot { it.id == siteId }
    }

    fun sendMessage(queryText: String? = null, overrideMode: SearchMode? = null) {
        val query = (queryText ?: _inputText.value).trim()
        if (query.isBlank()) return

        val mode = overrideMode ?: _selectedMode.value
        _inputText.value = ""
        stopTts()

        val userMessage = ChatMessage(
            id = UUID.randomUUID().toString(),
            isUser = true,
            text = query,
            mode = mode
        )

        val loadingAiMessageId = UUID.randomUUID().toString()
        val loadingAiMessage = ChatMessage(
            id = loadingAiMessageId,
            isUser = false,
            text = "",
            mode = mode,
            isLoading = true
        )

        _messages.value = _messages.value + userMessage + loadingAiMessage
        _isThinking.value = true

        val selectedDomains = _siteFilters.value
            .filter { it.isSelected }
            .map { it.domain }

        viewModelScope.launch {
            val result = repository.executeSearch(
                query = query,
                mode = mode,
                selectedDomains = selectedDomains
            )

            val primaryWiki = result.wikiArticles.firstOrNull()
            val otherWikis = if (result.wikiArticles.size > 1) result.wikiArticles.drop(1) else emptyList()

            val completedAiMessage = ChatMessage(
                id = loadingAiMessageId,
                isUser = false,
                text = result.aiOverview?.quickAnswer ?: (primaryWiki?.extract ?: "Ось інформація за вашим запитом:"),
                mode = mode,
                aiOverview = result.aiOverview,
                wikiArticle = primaryWiki,
                otherWikiArticles = otherWikis,
                webSources = result.webSources,
                googleSearchUrl = result.googleSearchUrl,
                isLoading = false,
                errorMessage = result.errorMessage,
                sites = selectedDomains
            )

            _messages.value = _messages.value.map { msg ->
                if (msg.id == loadingAiMessageId) completedAiMessage else msg
            }
            _isThinking.value = false
        }
    }

    fun explainWikipediaArticleInChat(messageId: String, article: WikipediaArticle) {
        viewModelScope.launch {
            val explainingSummary = repository.explainWikipediaArticleWithAi(article)
            _messages.value = _messages.value.map { msg ->
                if (msg.id == messageId && msg.wikiArticle != null) {
                    msg.copy(wikiArticle = msg.wikiArticle.copy(aiSummary = explainingSummary))
                } else msg
            }
        }
    }

    fun speakMessage(messageId: String, text: String) {
        if (_isTtsSpeaking.value && _speakingMessageId.value == messageId) {
            stopTts()
            return
        }
        val cleanText = text.replace(Regex("[#*_`\\[\\]]"), "")
        tts?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, "AI_SPEECH_ID")
        _isTtsSpeaking.value = true
        _speakingMessageId.value = messageId
    }

    fun stopTts() {
        tts?.stop()
        _isTtsSpeaking.value = false
        _speakingMessageId.value = null
    }

    fun clearChat() {
        stopTts()
        val welcomeMessage = ChatMessage(
            id = "welcome_msg_${System.currentTimeMillis()}",
            isUser = false,
            text = "Чат очищено ✨. Обирай вкладку зверху та надсилай новий пошуковий запит!",
            mode = _selectedMode.value
        )
        _messages.value = listOf(welcomeMessage)
    }

    fun openUrlInBrowser(context: Context, url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun shareText(context: Context, text: String, title: String = "Поділитися відповіддю AI") {
        try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, title)
                putExtra(Intent.EXTRA_TEXT, text)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(Intent.createChooser(intent, title).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            })
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun toggleFavorite(item: SearchHistoryEntity) {
        viewModelScope.launch {
            repository.toggleFavorite(item.id, !item.isFavorite)
        }
    }

    fun deleteHistoryItem(id: Long) {
        viewModelScope.launch {
            repository.deleteHistory(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAllHistory()
        }
    }

    fun setShowHistorySheet(show: Boolean) {
        _showHistorySheet.value = show
    }

    override fun onCleared() {
        super.onCleared()
        tts?.stop()
        tts?.shutdown()
    }
}
